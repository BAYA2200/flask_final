from . import models
from . import forms
from flask import request, render_template, redirect, url_for, flash
from . import db
from . import login_manager
from flask_login import login_user, logout_user, login_required, current_user
from datetime import datetime
from app.models import Post

# post function
def index():
    posts = models.Post.query.all()
    return render_template("index.html", posts=posts)


def post_add():
    form = forms.PostForm()
    if request.method == "POST":
        if form.validate_on_submit():
            post = models.Post(title=request.form.get("title"),
                               content=request.form.get("content"),
                               user_id=current_user.id,
                               date_posited=datetime.date().today())
            db.session.add(post)
            db.session.commit()
            flash("ВЫ ЗАРЕг")
            return redirect(url_for("index"))
        elif form.errors:
            for errors in form.errors.values():
                for error in errors:
                    flash(error, category="danger")
        return render_template("add_post.html", form=form)

def post_detail(post_id):
    post = Post.query.filter_by(id=post_id).first()
    if post:
        return render_template("post_detail.html", post=post)
    else:
        flash("Пост не был найден", category="danger")
        return render_template(url_for("login"))

def post_delete(post_id):
    post = Post.query.filter_by(id=post_id).first()
    if post:
        if request.method == "GET":
            return render_template("post_delete.html", post=post)
        if request.method == "POST":
            db.session.delete(post)
            db.session.commit()
            flash("Пост успешно удален", category="success")
            return redirect(url_for("login"))
        else:
            form = forms.PostForm()
            return render_template("post_delete.html", post=post, form=form)




def register():
    form = forms.UserForm()
    if request.method == "POST":
        if form.validate_on_submit():
            user = models.User(username=request.form.get("username"), password=request.form.get("password"))
            db.session.add(user)
            db.session.commit()
            flash("ВЫ зарег ")
            return redirect(url_for("login"))
        elif form.errors:
            for errors in form.errors.values():
                for error in errors:
                    flash(error, category="danger")
    return render_template("register.html", form=form)


def login():
    form = forms.UserForm()
    if request.method == "POST":
        if form.validate_on_submit():
            user = models.User.query.filter_by(username=request.form.get("username")).first()
            if user and user.check_password(request.form.get("password")):
                login_user(user)
                flash("Зарег", category="success")
                return redirect(url_for("index"))
            else:
                flash("Неверный догин", category="success")
        elif form.errors:
            for errors in form.errors.values():
                for error in errors:
                    flash(error, category="danger")
    return render_template("login.html", form=form)

# @login_manager.user_loader
